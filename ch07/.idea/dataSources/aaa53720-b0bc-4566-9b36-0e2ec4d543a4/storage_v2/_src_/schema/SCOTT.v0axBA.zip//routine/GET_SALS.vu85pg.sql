create procedure  get_sals(cur_salary in out  sys_refcursor)
as
begin
  open cur_salary for
     select  empno,sal from emp;
end;
/

