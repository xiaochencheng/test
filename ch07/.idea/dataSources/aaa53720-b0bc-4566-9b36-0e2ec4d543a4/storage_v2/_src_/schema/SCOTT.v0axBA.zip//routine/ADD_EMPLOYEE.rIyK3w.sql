create procedure  add_employee(
   eno  employee.empno%type,
   name employee.ename%type,
   salary employee.sal%type,
   job employee.job%type,
   dno employee.deptno%type,
   on_Flag OUT  number,
   os_Msg  OUT  varchar2
)
is
begin
  insert into employee(empno,ename,sal,job,deptno)values(eno,name,salary,job,dno);
  on_Flag:=1;
  os_Msg:='添加成功';
EXCEPTION
  when dup_val_on_Index then
    on_Flag:=-1;
    os_Msg:='该员工已存在。';
  when  others  then
    on_Flag:=-2;
    os_Msg:='其他错误，与管理员联系。';
end;
/

